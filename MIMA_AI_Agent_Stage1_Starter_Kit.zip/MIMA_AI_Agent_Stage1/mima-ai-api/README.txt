MIMA AI AGENT — STAGE 1 PHP BACKEND

1. In cPanel File Manager, open public_html.
2. Create public_html/mima-ai-api.
3. Upload the contents of this folder into it.
4. Copy config.sample.php to config.php.
5. Edit config.php and replace the placeholder with a long random secret.
6. Test: https://www.mimaengineeringltd.com/mima-ai-api/?action=health

Authenticated status endpoint:
GET https://www.mimaengineeringltd.com/mima-ai-api/?action=status
Header: Authorization: Bearer YOUR_SECRET_API_KEY

Task test endpoint:
POST https://www.mimaengineeringltd.com/mima-ai-api/?action=task
Headers: Authorization: Bearer YOUR_SECRET_API_KEY
         Content-Type: application/json
Body: {"message":"Prepare a weekly equipment listing report"}

IMPORTANT:
- This is a Stage 1 foundation, not a fully autonomous agent.
- It does not yet call OpenAI or modify marketplace records.
- The task endpoint only validates and acknowledges a request.
- Keep config.php and the API key private. Use HTTPS only.
- It does not overwrite existing marketplace files or database.
- PHP 8.1+ recommended.
