<?php
declare(strict_types=1);
return [
    'app_name' => 'MIMA AI Agent',
    'api_key' => 'REPLACE_WITH_A_LONG_RANDOM_SECRET',
];
