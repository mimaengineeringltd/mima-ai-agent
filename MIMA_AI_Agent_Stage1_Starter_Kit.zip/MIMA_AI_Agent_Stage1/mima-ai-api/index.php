<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    http_response_code(503);
    echo json_encode(['ok'=>false,'error'=>'API_NOT_CONFIGURED','message'=>'Create config.php from config.sample.php.']);
    exit;
}
$config = require $configFile;

function respond(int $status, array $data): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

$action = $_GET['action'] ?? '';
if ($action === 'health') {
    respond(200, ['ok'=>true,'service'=>'MIMA AI Agent API','version'=>'0.1.0','status'=>'online','timestamp'=>gmdate('c')]);
}

$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$provided = preg_match('/Bearer\s+(.+)/i', $auth, $m) ? trim($m[1]) : '';
$expected = (string)($config['api_key'] ?? '');
if ($expected === '' || $expected === 'REPLACE_WITH_A_LONG_RANDOM_SECRET') {
    respond(503, ['ok'=>false,'error'=>'API_NOT_CONFIGURED','message'=>'Set a secure API key in config.php.']);
}
if ($provided === '' || !hash_equals($expected, $provided)) {
    respond(401, ['ok'=>false,'error'=>'UNAUTHORIZED','message'=>'A valid API key is required.']);
}
if ($action === 'status') {
    respond(200, [
        'ok'=>true,'agent'=>'MIMA AI Agent','stage'=>1,
        'capabilities'=>['mobile_dashboard','secure_api_connection'],
        'integrations'=>['website_marketplace'=>'not_connected','email'=>'not_connected','mima_erp'=>'planned']
    ]);
}
if ($action === 'task' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    $message = trim((string)($body['message'] ?? ''));
    if ($message === '') respond(422, ['ok'=>false,'error'=>'MESSAGE_REQUIRED']);
    if (strlen($message) > 2000) respond(422, ['ok'=>false,'error'=>'MESSAGE_TOO_LONG']);
    respond(202, [
        'ok'=>true,'accepted'=>false,'stage'=>1,
        'message'=>'Stage 1 API is ready. Task execution will be enabled after the AI engine and approval workflow are connected.',
        'received_message'=>$message
    ]);
}
respond(404, ['ok'=>false,'error'=>'NOT_FOUND']);
