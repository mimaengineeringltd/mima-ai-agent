package com.mima.aiagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

private val Navy = Color(0xFF173B65)
private val client = OkHttpClient()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MimaAgentApp() }
    }
}

@Composable
fun MimaAgentApp() {
    var apiUrl by remember { mutableStateOf("https://www.mimaengineeringltd.com/mima-ai-api/") }
    var apiKey by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Not connected") }
    var details by remember { mutableStateOf("Enter your private API key and test the connection.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy)) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFFF4F6F9))
                .verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Column(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(18.dp)).padding(20.dp)) {
                Text("MIMA AI", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("BUSINESS AGENT", color = Color.White, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text("Your business operations assistant", color = Color.White)
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backend connection", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(apiUrl, { apiUrl = it }, label = { Text("API base URL") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Private API key") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = {
                        scope.launch {
                            busy = true
                            status = "Checking..."
                            details = testBackend(apiUrl, apiKey)
                            status = if (details.startsWith("Connected")) "Connected" else "Not connected"
                            busy = false
                        }
                    }, enabled = !busy && apiKey.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                        Text(if (busy) "Checking..." else "Test connection")
                    }
                    Text("Status: $status")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Agent workspace", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Stage 1 dashboard foundation. AI task execution will be enabled after the AI engine and approval workflow are connected.")
                    Text("Planned modules", fontWeight = FontWeight.SemiBold)
                    listOf("Equipment marketplace", "Customer enquiries", "Marketing and adverts",
                        "Quotations and invoices", "Business reports").forEach { Text("• $it") }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Connection details", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(details, color = Color(0xFF475467))
                }
            }
            Text("MIMA ENGINEERING SOLUTIONS LTD", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

private suspend fun testBackend(base: String, key: String): String = withContext(Dispatchers.IO) {
    try {
        val url = base.trim().trimEnd('/') + "/?action=status"
        val request = Request.Builder().url(url).header("Authorization", "Bearer ${key.trim()}").get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful) "Connected. Backend response: $body"
            else "Connection failed (${response.code}). Check API key and setup. $body"
        }
    } catch (e: Exception) {
        "Connection error: ${e.message ?: "Unknown error"}"
    }
}
