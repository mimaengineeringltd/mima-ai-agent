MIMA AI AGENT — ANDROID STAGE 1 SOURCE

This is Android Studio source code, not an APK.
Open the MimaAIAgentAndroid folder in Android Studio and allow Gradle sync.
Then select Build > Build Bundle(s) / APK(s) > Build APK(s).

Default API URL:
https://www.mimaengineeringltd.com/mima-ai-api/

The app currently tests the authenticated PHP backend status endpoint.
The API key is held in app memory for the current session only.
Do not share screenshots containing your API key.
